package Tests;

import Pages.P01_LoginPage;
import Utilities.DataUtil;
import Utilities.LogsUtil;
import Utilities.Utility;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;

import Listeners.IInvokedMethodListenerClass;
import Listeners.ITestResultListenerClass;

import static DriverFactory.DriverFactory.getDriver;
import static DriverFactory.DriverFactory.setUpDriver;
import static Utilities.DataUtil.getPropertyValue;

@Listeners({IInvokedMethodListenerClass.class, ITestResultListenerClass.class})
public class TC01_LoginTest {

    @BeforeMethod
    public void driverSetUp() throws IOException {
        setUpDriver(getPropertyValue("enviroment", "Browser"));
        LogsUtil.info("Browser is opened");
        getDriver().get(DataUtil.getPropertyValue("enviroment","LoginURL"));
        LogsUtil.info("we are in the login page now");
        getDriver().manage().timeouts()
                .implicitlyWait(Duration.ofSeconds(10));
    }
    //TODO: Valid login TC by email and password
//TODO: Valid Login TC by Linkedin
    @Test
    public void validLoginByLinkedinTC() throws IOException {
       new P01_LoginPage(getDriver())
               .clickOnLoginwithLinkedinButton()
               .linkedinEnterEmail(DataUtil.getJsonData("validLoginData","email"))
               .linkedinEnterPassword(DataUtil.getJsonData("validLoginData", "Password")).linkedinClickOnLogin();
       Utility.ExplicitWaitByURL(getDriver(),getPropertyValue("enviroment", "Home_URL"));
        Assert.assertTrue(new P01_LoginPage(getDriver()).assertLogin(getPropertyValue("enviroment", "Home_URL")));

    }

    //TODO: Invalid login TC by email and password
    // TODO: Invalid Login TC by Linkedin
    // TODO: Invalid Login TC by Linkedin
    //TODO: Verify if the forget password button works properly
    //TODO: Verify if the Linkedin Redirection  button works properly
    //TODO: Verify if the Dark Mode Sign button works properly
    //TODO: Verify if the Language Switch button works properly
    @AfterMethod
    public void DriverQuit (){
        getDriver().quit();
    }
}
