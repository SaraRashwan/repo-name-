package Tests;
import Pages.P01_LoginPage;
import Pages.P02_CreatePostPage;
import Pages.P03_WritingCommentPage;
import Utilities.DataUtil;
import Utilities.LogsUtil;
import Utilities.Utility;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;

import Listeners.IInvokedMethodListenerClass;
import Listeners.ITestResultListenerClass;

import static DriverFactory.DriverFactory.getDriver;
import static DriverFactory.DriverFactory.setUpDriver;
import static Utilities.DataUtil.getPropertyValue;

@Listeners({IInvokedMethodListenerClass.class, ITestResultListenerClass.class})

public class TC03_WritingCommentTest {
    @BeforeMethod
    public void driverSetUp() throws IOException {
        setUpDriver(getPropertyValue("enviroment", "Browser"));
        LogsUtil.info("Browser is opened");
        getDriver().get(DataUtil.getPropertyValue("enviroment","LoginURL"));
        LogsUtil.info("we are in the login page now");
        getDriver().manage().timeouts()
                .implicitlyWait(Duration.ofSeconds(10));
    }
    @Test
    public void createPostWithCommentTC() throws IOException, InterruptedException {
        //TODO Login Steps
        new P01_LoginPage(getDriver())
                .clickOnLoginwithLinkedinButton()
                .linkedinEnterEmail(DataUtil.getJsonData("validLoginData","email"))
                .linkedinEnterPassword(DataUtil.getJsonData("validLoginData", "Password"))
                .linkedinClickOnLogin();
        Utility.ExplicitWaitByURL(getDriver(),getPropertyValue("enviroment", "Home_URL"));
        //TODO Create Post Steps
        new P02_CreatePostPage(getDriver())
                .clickOnCreatePostFrame()
                .enterYourPost(DataUtil.getJsonData("createPostwithImage","CommentedPostText"));
        LogsUtil.info("Text is " + DataUtil.getJsonData("createPostwithImage","CommentedPostText"));
        new P02_CreatePostPage(getDriver())
                .clickOnSubmitButton()
                .clickOnCommentIcon();
        //TODO writing Comment Steps
        new P03_WritingCommentPage(getDriver())
                .enterYourComment(DataUtil.getJsonData("createPostwithImage","CommentText"))
                        .clickOnSubmitComment();
        Utility.ExplicitWaitByURL(getDriver(),getPropertyValue("enviroment", "Home_URL"));
        LogsUtil.info("The current URL is" + getDriver().getCurrentUrl());
        Assert.assertTrue(new P03_WritingCommentPage(getDriver())
                .AssertCommentSubmitted(DataUtil.getPropertyValue("enviroment", "Home_URL")));
    }
    @AfterMethod
    public void DriverQuit (){
        getDriver().quit();
    }
}
