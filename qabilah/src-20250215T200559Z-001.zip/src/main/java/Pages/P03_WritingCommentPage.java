package Pages;

import Utilities.Utility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class P03_WritingCommentPage {
    private final WebDriver driver;
    private final By writingCommentLocator = By.xpath("//div[contains(@aria-placeholder,'Enrich the discussion with a comment')]");
    private final By submitComment = By.xpath("//button[contains(@class,'bottom-[13px]')]");

    public P03_WritingCommentPage(WebDriver driver) {
        this.driver = driver;
    }
    public P03_WritingCommentPage enterYourComment(String Text) {
        Actions actions = new Actions(driver);
        actions.click(Utility.findWebElement(driver, writingCommentLocator)).sendKeys(Text).perform();
        return this;
    }
    public void clickOnSubmitComment(){
        Utility.generalWait(driver);
        Utility.clickOnElement(driver, submitComment);
    }
    public boolean AssertCommentSubmitted(String expectedValue){
        return driver.getCurrentUrl().equals(expectedValue);
    }
}
