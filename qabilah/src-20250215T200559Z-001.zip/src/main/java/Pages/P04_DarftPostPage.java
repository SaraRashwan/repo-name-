package Pages;

import Utilities.Utility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.time.Duration;

public class P04_DarftPostPage {
    private final WebDriver driver;
    private final By saveDraftButton = By.xpath("//button[contains(@class,'h-9 px-4 py-2 sm:h-8 w-full sm:w-auto')]");
    private final By draftedPostsPage = By.xpath("//ul[contains(@class,'mt-6')]/li[6]");
    private final By deleteDraftedPost = By.xpath("//button[contains(@class,'text-sm p-2 items-center')]");
    private final By confirmDeleteDraft = By.xpath("//button[contains(@class,'bg-red-500')]");

    public P04_DarftPostPage(WebDriver driver) {
        this.driver = driver;
    }
    public P04_DarftPostPage clickOnDraftButton(){
        Utility.clickOnElement(driver,saveDraftButton);
        return this;
    }
    public P04_DarftPostPage clickOnDraftPageIcon(){
        Utility.scrolling(driver,draftedPostsPage);
        Utility.clickOnElement(driver,draftedPostsPage);
        return this;
    }
    public P04_DarftPostPage clickOnDeleteDraftedPost(){
        Utility.ExplicitWaitByLocator(driver,deleteDraftedPost);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        Utility.clickOnElement(driver,deleteDraftedPost);
        return this;
    }
    public P04_DarftPostPage clickOnConfirm(){
        Utility.ExplicitWaitByLocator(driver,confirmDeleteDraft);
        Utility.clickOnElement(driver,confirmDeleteDraft);
        return this;
    }
    public boolean AssertDraftPageURL(String expectedValue){
        return driver.getCurrentUrl().equals(expectedValue);
    }

}
