package Pages;

import Utilities.Utility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class P01_LoginPage {
    private WebDriver driver;
    private final By EmailField = By.cssSelector("[type=\"email\"]");
    private final By PasswordField = By.cssSelector("[type=\"password\"]");
    private final By LoginButton = By.xpath("//button[contains(@class,'inline-flex')]");
    private final By LoginToLinkedinPage = By.xpath("//button[contains(@class,'gap-2')]");
    private final By ForgetPasswordButton = By.className("text-center");
    private final By LinkedinRedirectionButton = By.cssSelector("[target=\"_blank\"]");
    private final By DarkModeSign= By.cssSelector("[width=\"24\"]");
    private final By LanguageSwitch = By.xpath("//div/div/div/button");
    private final By PasswordHideSign = By.cssSelector("[cx=\"12\"]");
    private final By LinkedinEmailField = By.cssSelector("#username");
    private final By LinkedinPasswordField = By.cssSelector("#password");
    private final By LinkedinpageLoginButton = By.cssSelector("[data-litms-control-urn='login-submit']");


    public  P01_LoginPage (WebDriver driver){
        this.driver = driver;
    }

    public P01_LoginPage enterEmail(String email){
        driver.findElement(EmailField).sendKeys(email);
        return this;
    }
    public P01_LoginPage enterPassword(String password){
        driver.findElement(PasswordField).sendKeys(password);
        return this;
    }
    public P02_CreatePostPage clickOnLogin(){
        driver.findElement(LoginButton).click();
        return new P02_CreatePostPage(driver);
    }
    public P01_LoginPage clickOnLoginwithLinkedinButton() {
        Utility.clickOnElement(driver,LoginToLinkedinPage);
        return this;
    }
    public P01_LoginPage linkedinEnterEmail(String email){
        Utility.sendData(driver,LinkedinEmailField,email);
        return this;
    }
    public P01_LoginPage linkedinEnterPassword(String password){
        Utility.sendData(driver,LinkedinPasswordField,password);
        return this;
    }
    public P02_CreatePostPage linkedinClickOnLogin(){
        Utility.clickOnElement(driver, LinkedinpageLoginButton);
        return new P02_CreatePostPage(driver);
    }
    public P01_LoginPage clickOnForgetPassword(){
        driver.findElement(ForgetPasswordButton).click();
        return this;
    }
    public void clickOnLinkedInReferenceLink(){
        driver.findElement(LinkedinRedirectionButton).click();
    }
    public void clickOnThemeModeSwitching(){
        driver.findElement(DarkModeSign).click();
    }
    public void clickOnLanguageSwitching(){
        driver.findElement(LanguageSwitch).click();
    }
    public void clickOnPasswordHideSign(){
        driver.findElement(PasswordHideSign).click();
    }
    public boolean assertLogin(String expectedValue){
        return driver.getCurrentUrl().equals(expectedValue);
    }


}

