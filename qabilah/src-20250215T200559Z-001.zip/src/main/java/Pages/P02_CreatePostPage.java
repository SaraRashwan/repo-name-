package Pages;

import Utilities.Utility;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.io.IOException;
import java.util.List;

import static DriverFactory.DriverFactory.getDriver;
import static Utilities.DataUtil.getPropertyValue;

public class P02_CreatePostPage {

    private WebDriver driver;
    private final By clickOnCreatePostField = By.xpath("//div[contains(@class,'flex-1')]//div[contains(@class,'text-secondaryText ')]");
    private final By creatingPostLocator = By.xpath("//div[contains(@class,'absolute top-1')]");
    private final By imageIconLocator = By.xpath("//div[contains(@class,'gap-[3px]')]/button[contains(@class,'p-1')]");
    private final By addImageLocator = By.xpath("//div[contains(@class,'py-5')]");
    private final By importImageLocator = By.xpath("//div[contains(@class,'py-5')]/input[contains(@accept,'image')]");
    private final By submitButton = By.cssSelector("button>div[class='min-w-10']");
    private final By importedImageLocator = By.xpath("//div[2]/div/div[4]/div/div/div/button");
    private final By schedulePostToggleLocator = By.id("timer");
    private final By publishDateLocator = By.xpath("//*[@id=\"radix-:r84:\"]/div[2]/div/div[4]/div[2]/div[1]/div/div[2]/form/div/div[1]/div/button");
    private final By enterTimeFieldLocator = By.xpath("//button[contains(@id,'form-item')]");
    private final By publishTimeLocator = By.xpath("//div[contains(@data-selected,'true')]");
    private final By scheduleButtonLocator = By.xpath("//div[contains(@class,'flex items-center')]/button[contains(@class,'whitespace')]");
    private final By XButtonLocator = By.xpath("//button[contains(@class,'text-muted-foreground')]");

    public P02_CreatePostPage(WebDriver driver) {
        this.driver = driver;
    }

    public P02_CreatePostPage clickOnCreatePostFrame() {
        Utility.clickOnElement(driver, clickOnCreatePostField);
        return this;
    }

    public P02_CreatePostPage enterYourPost(String Text) {
        Actions actions = new Actions(driver);
        actions.click(Utility.findWebElement(driver, creatingPostLocator)).sendKeys(Text).perform();
        return this;
    }

    public P02_CreatePostPage clickOnImageIcon() {
        Utility.clickOnElement(driver, imageIconLocator);
        return this;
    }
    public P02_CreatePostPage clickOnAddImage() {
        Utility.ExplicitWaitByLocator(driver,addImageLocator);
        Utility.clickOnElement(driver, addImageLocator);
        return this;
    }
    public P02_CreatePostPage importImageToPost(String imagePath) throws InterruptedException {
        Utility.sendData(driver,importImageLocator,imagePath);
        return this;
    }
    public P02_CreatePostPage clickOnSubmitButton(){
        Utility.ExplicitWaitByLocator(driver,importedImageLocator);
        Utility.clickOnElement(driver, submitButton);
        return this;
    }
    public boolean AssertPostImage(String expectedValue){
            return driver.getCurrentUrl().equals(expectedValue);
    }
    public P02_CreatePostPage clickOnSchedualetoggle(){
        Utility.ExplicitWaitByLocator(driver,schedulePostToggleLocator);
        Utility.clickOnElement(driver, schedulePostToggleLocator);
        return this;
    }
    public P02_CreatePostPage enterDate(String Date){
        Utility.sendData(driver,publishDateLocator, Date);
        return this;
    }
    public P02_CreatePostPage clickOnEnterTime() {
        Utility.ExplicitWaitByLocator(driver, enterTimeFieldLocator);
        Utility.clickOnElement(driver, enterTimeFieldLocator);
        return this;
    }
    public P02_CreatePostPage chooseTime(){
        Utility.ExplicitWaitByLocator(driver,publishTimeLocator);
        Utility.clickOnElement(driver,publishTimeLocator);
        return this;
    }
    public void clickOnScheduleButton(){
        Utility.ExplicitWaitByLocator(driver,scheduleButtonLocator);
        Utility.clickOnElement(driver, scheduleButtonLocator);
    }
    public P03_WritingCommentPage clickOnCommentIcon() throws IOException {
        // Get the last post ID
        String lastPostId = Utility.theLastPostID(driver);
        // Construct the dynamic XPath for the comment icon
        String dynamicXPath = "//div[@data-id='comment-icon-"+lastPostId+"']";
        System.out.println("dynamicXPath ID: " + dynamicXPath);
        Utility.ExplicitWaitByLocator(driver,By.xpath(dynamicXPath));
        Utility.clickOnElement(driver,By.xpath(dynamicXPath));
        return new P03_WritingCommentPage(driver);
    }
    public P04_DarftPostPage clickOnXButton(){
        Utility.clickOnElement(driver,XButtonLocator);
        return new P04_DarftPostPage(driver);
    }
}
